import 'package:mqtt_client/mqtt_client.dart';
import 'package:mqtt_client/mqtt_server_client.dart';
import 'dart:convert';

class MqttService {
  late MqttServerClient client;
  String broker = 'test.mosquitto.org';
  int port = 1883;
  String topic = 'kolam_ikan/data';

  Function(Map<String, dynamic>)? onDataReceived;

  void setConfiguration({required String broker, required int port, required String topic}) {
    this.broker = broker;
    this.port = port;
    this.topic = topic;
  }

  Future<void> connect() async {
    client = MqttServerClient.withPort(broker, 'flutter_kolam_ikan', port);
    client.logging(on: false);
    client.keepAlivePeriod = 20;
    client.onConnected = onConnected;
    client.onDisconnected = onDisconnected;
    client.onSubscribed = onSubscribed;

    final connMessage = MqttConnectMessage()
        .withClientIdentifier('flutter_kolam_ikan')
        .withWillTopic('willtopic')
        .withWillMessage('Connection Closed')
        .startClean()
        .withWillQos(MqttQos.atLeastOnce);

    client.connectionMessage = connMessage;

    try {
      await client.connect();
    } catch (e) {
      print('MQTT Connection Error: $e');
      disconnect();
      return;
    }

    if (client.connectionStatus!.state == MqttConnectionState.connected) {
      print('MQTT Connected');
      client.subscribe(topic, MqttQos.atMostOnce);
      client.updates!.listen((List<MqttReceivedMessage<MqttMessage?>>? event) {
        final recMess = event![0].payload as MqttPublishMessage;
        final payload = MqttPublishPayload.bytesToStringAsString(recMess.payload.message);
        print('Payload received: $payload');

        try {
          final decoded = jsonDecode(payload);
          if (decoded is Map<String, dynamic>) {
            onDataReceived?.call(decoded);
          } else {
            print('Decoded data is not a JSON object');
          }
        } catch (e) {
          print('Error decoding JSON: $e');
        }
      });
    } else {
      print('MQTT Connection Failed - Status: ${client.connectionStatus}');
    }
  }

  void disconnect() {
    client.disconnect();
  }

  void onConnected() {
    print('Connected to MQTT broker');
  }

  void onDisconnected() {
    print('Disconnected from MQTT broker');
  }

  void onSubscribed(String topic) {
    print('Subscribed to $topic');
  }
}
