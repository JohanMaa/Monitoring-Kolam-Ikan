import 'package:flutter/material.dart';
import '../pages/dashboard_page.dart';

class SensorCard extends StatelessWidget {
  final SensorCardData data;

  const SensorCard({Key? key, required this.data}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Container(
      margin: const EdgeInsets.symmetric(vertical: 8.0),
      padding: const EdgeInsets.all(16.0),
      decoration: BoxDecoration(
        color: Colors.black87,
        borderRadius: BorderRadius.circular(16.0),
        border: Border.all(color: data.color.withOpacity(0.5), width: 1.5),
        boxShadow: [
          BoxShadow(
            color: data.color.withOpacity(0.4),
            blurRadius: 8,
            offset: Offset(0, 4),
          ),
        ],
      ),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.center,
        children: [
          data.icon, // langsung gunakan widget icon-nya
          SizedBox(width: 16.0),
          Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(
                data.label,
                style: TextStyle(color: Colors.white70, fontSize: 14.0),
              ),
              SizedBox(height: 4.0),
              Text(
                data.value,
                style: TextStyle(color: data.color, fontSize: 20.0, fontWeight: FontWeight.bold),
              ),
            ],
          ),
        ],
      ),
    );
  }
}
