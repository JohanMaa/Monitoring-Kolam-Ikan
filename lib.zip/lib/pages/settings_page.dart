import 'package:flutter/material.dart';
import '../services/mqtt_service.dart';

class SettingsPage extends StatefulWidget {
  final MqttService mqttService;

  const SettingsPage({Key? key, required this.mqttService}) : super(key: key);

  @override
  _SettingsPageState createState() => _SettingsPageState();
}

class _SettingsPageState extends State<SettingsPage> {
  final TextEditingController _brokerController = TextEditingController(text: 'broker.hivemq.com');
  final TextEditingController _portController = TextEditingController(text: '1883');
  final TextEditingController _topicController = TextEditingController(text: 'kolam_ikan/data');

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Pengaturan MQTT'),
      ),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          children: [
            TextField(
              controller: _brokerController,
              decoration: InputDecoration(labelText: 'Broker MQTT'),
            ),
            TextField(
              controller: _portController,
              keyboardType: TextInputType.number,
              decoration: InputDecoration(labelText: 'Port'),
            ),
            TextField(
              controller: _topicController,
              decoration: InputDecoration(labelText: 'Topik'),
            ),
            SizedBox(height: 20),
            ElevatedButton(
              onPressed: () {
                final broker = _brokerController.text;
                final port = int.tryParse(_portController.text) ?? 1883;
                final topic = _topicController.text;

                widget.mqttService.disconnect();
                widget.mqttService.setConfiguration(broker: broker, port: port, topic: topic);
                widget.mqttService.connect();

                ScaffoldMessenger.of(context).showSnackBar(
                  SnackBar(content: Text('Konfigurasi diterapkan: $broker:$port [$topic]')),
                );
              },
              child: Text('Simpan dan Sambungkan'),
            ),
          ],
        ),
      ),
    );
  }
}