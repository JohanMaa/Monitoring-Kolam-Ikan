import 'package:flutter/material.dart';
import 'package:line_icons/line_icons.dart';
import '../widgets/sensor_card.dart';
import '../services/mqtt_service.dart';
import 'settings_page.dart';
import 'package:font_awesome_flutter/font_awesome_flutter.dart';
import 'connection_page.dart';

class DashboardPage extends StatefulWidget {
  @override
  _DashboardPageState createState() => _DashboardPageState();
}

class _DashboardPageState extends State<DashboardPage> {
  late MqttService mqttService;
  int _selectedIndex = 0;

  List<SensorCardData> sensorData = [
    SensorCardData(
      icon: FaIcon(FontAwesomeIcons.temperatureHalf, color: Color(0xFFE63946)), 
      label: 'Suhu', 
      value: '0.0 °C', 
      color: Color(0xFFE63946),
    ),
    SensorCardData(
      icon: FaIcon(FontAwesomeIcons.droplet, color: Color(0xFF1D3557)), 
      label: 'Kadar DO', 
      value: '0.0 mg/L', 
      color: Color(0xFF1D3557),
    ),
    SensorCardData(
      icon: FaIcon(FontAwesomeIcons.vial, color: Color(0xFF2A9D8F)), 
      label: 'pH Air', 
      value: '0.0', 
      color: Color(0xFF2A9D8F),
    ),
    SensorCardData(
      icon: FaIcon(Icons.scale, color: Color(0xFFF4A261)), 
      label: 'Berat Pakan', 
      value: '0.0 Kg', 
      color: Color(0xFFF4A261),
    ),
    SensorCardData(
      icon: FaIcon(FontAwesomeIcons.water, color: Color(0xFFE9C46A)), 
      label: 'Ketinggian Air', 
      value: '0%', 
      color: Color(0xFFE9C46A),
    ),
  ];

  @override
  void initState() {
    super.initState();
    mqttService = MqttService();
    mqttService.onDataReceived = updateSensorData;
    mqttService.connect();
  }

  void updateSensorData(Map<String, dynamic> data) {
    setState(() {
      sensorData[0] = sensorData[0].copyWith(value: '${data['suhu'] ?? '0.0'} °C');
      sensorData[1] = sensorData[1].copyWith(value: '${data['do'] ?? '0.0'} mg/L');
      sensorData[2] = sensorData[2].copyWith(value: '${data['ph'] ?? '0.0'}');
      sensorData[3] = sensorData[3].copyWith(value: '${data['berat_pakan'] ?? '0.0'} Kg');
      sensorData[4] = sensorData[4].copyWith(value: '${data['level_air'] ?? '0'}%');
    });
  }

  @override
  void dispose() {
    mqttService.disconnect();
    super.dispose();
  }

  List<Widget> get _pages => [
    _buildDashboardView(),
    _buildConnectionPage(),
    _buildHistoryPage(),
    SettingsPage(mqttService: mqttService),
  ];

  Widget _buildDashboardView() {
    return ListView.builder(
      padding: const EdgeInsets.all(16),
      itemCount: sensorData.length,
      itemBuilder: (context, index) {
        final data = sensorData[index];
        return SensorCard(data: data);
      },
    );
  }

  Widget _buildConnectionPage() {
    return ConnectionPage(
      mqttService: mqttService,
      onConnected: () {
        setState(() {}); // Biar update tampilan setelah koneksi berhasil
      },
    );
  }

  Widget _buildHistoryPage() {
    return Center(
      child: Padding(
        padding: const EdgeInsets.all(20.0),
        child: Text(
          'Tidak ada history',
          textAlign: TextAlign.center,
          style: TextStyle(fontSize: 16),
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Monitoring Kolam Ikan'),
      ),
      body: _pages[_selectedIndex],
      bottomNavigationBar: BottomNavigationBar(
        selectedItemColor: Colors.cyan,
        unselectedItemColor: Colors.white54,
        backgroundColor: Colors.black,
        items: [
          BottomNavigationBarItem(
            icon: FaIcon(FontAwesomeIcons.dashboard),
            label: 'Dashboard',
          ),
          BottomNavigationBarItem(
            icon: Icon(LineIcons.connectDevelop),
            label: 'Connection',
          ),
          BottomNavigationBarItem(
            icon: FaIcon(FontAwesomeIcons.clockRotateLeft),
            label: 'History',
          ),
          BottomNavigationBarItem(
            icon: Icon(LineIcons.cog),
            label: 'Setting',
          ),
        ],
        currentIndex: _selectedIndex,
        onTap: (index) {
          setState(() {
            _selectedIndex = index;
          });
        },
        type: BottomNavigationBarType.fixed,
      ),
    );
  }
}

class SensorCardData {
  final Widget icon;
  final String label;
  final String value;
  final Color color;

  SensorCardData({
    required this.icon,
    required this.label,
    required this.value,
    required this.color,
  });

  SensorCardData copyWith({String? value}) {
    return SensorCardData(
      icon: this.icon,
      label: this.label,
      value: value ?? this.value,
      color: this.color,
    );
  }
}
