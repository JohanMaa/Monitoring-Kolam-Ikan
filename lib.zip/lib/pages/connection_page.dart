import 'package:flutter/material.dart';
import 'package:fluttertoast/fluttertoast.dart';
import 'package:shared_preferences/shared_preferences.dart';
import '../services/mqtt_service.dart';

class ConnectionPage extends StatefulWidget {
  final MqttService mqttService;
  final VoidCallback onConnected;

  const ConnectionPage({
    Key? key,
    required this.mqttService,
    required this.onConnected,
  }) : super(key: key);

  @override
  _ConnectionPageState createState() => _ConnectionPageState();
}

class _ConnectionPageState extends State<ConnectionPage> {
  final _formKey = GlobalKey<FormState>();
  final TextEditingController brokerController = TextEditingController();
  final TextEditingController portController = TextEditingController();
  final TextEditingController topicController = TextEditingController();

  String _statusMessage = 'Belum terkoneksi';

  @override
  void initState() {
    super.initState();
    _loadSavedConfiguration();
  }

  Future<void> _loadSavedConfiguration() async {
    SharedPreferences prefs = await SharedPreferences.getInstance();
    if (!mounted) return;
    setState(() {
      brokerController.text = prefs.getString('mqtt_broker') ?? widget.mqttService.broker;
      portController.text = prefs.getInt('mqtt_port')?.toString() ?? widget.mqttService.port.toString();
      topicController.text = prefs.getString('mqtt_topic') ?? widget.mqttService.topic;
    });
  }

  Future<void> _saveConfiguration() async {
    SharedPreferences prefs = await SharedPreferences.getInstance();
    await prefs.setString('mqtt_broker', brokerController.text);
    await prefs.setInt('mqtt_port', int.parse(portController.text));
    await prefs.setString('mqtt_topic', topicController.text);
  }

  @override
  void dispose() {
    brokerController.dispose();
    portController.dispose();
    topicController.dispose();
    super.dispose();
  }

  Future<void> _connectToBroker() async {
    if (_formKey.currentState!.validate()) {
      try {
        if (mounted) {
          setState(() {
            _statusMessage = 'Menyambungkan...';
          });
        }

        widget.mqttService.setConfiguration(
          broker: brokerController.text,
          port: int.parse(portController.text),
          topic: topicController.text,
        );

        await _saveConfiguration();

        await widget.mqttService.connect();

        if (mounted) {
          setState(() {
            _statusMessage = 'Terhubung ke MQTT broker';
          });

          Fluttertoast.showToast(
            msg: "Berhasil terhubung ke broker",
            toastLength: Toast.LENGTH_SHORT,
            gravity: ToastGravity.BOTTOM,
            backgroundColor: Colors.green,
            textColor: Colors.white,
          );

          widget.onConnected(); // hanya dipanggil jika masih mounted
        }
      } catch (e) {
        if (mounted) {
          setState(() {
            _statusMessage = 'Gagal terhubung: $e';
          });

          Fluttertoast.showToast(
            msg: "Gagal terhubung: $e",
            toastLength: Toast.LENGTH_LONG,
            gravity: ToastGravity.BOTTOM,
            backgroundColor: Colors.red,
            textColor: Colors.white,
          );
        }
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    return SingleChildScrollView(
      padding: const EdgeInsets.all(24.0),
      child: Form(
        key: _formKey,
        child: Column(
          children: [
            Icon(Icons.wifi, size: 80, color: Colors.cyan),
            const SizedBox(height: 16),
            Text(
              'Konfigurasi Koneksi',
              style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold),
            ),
            const SizedBox(height: 24),
            TextFormField(
              controller: brokerController,
              decoration: InputDecoration(labelText: 'Broker MQTT'),
              validator: (value) {
                if (value == null || value.isEmpty) {
                  return 'Broker tidak boleh kosong';
                }
                return null;
              },
            ),
            const SizedBox(height: 16),
            TextFormField(
              controller: portController,
              decoration: InputDecoration(labelText: 'Port'),
              keyboardType: TextInputType.number,
              validator: (value) {
                if (value == null || value.isEmpty) {
                  return 'Port tidak boleh kosong';
                }
                if (int.tryParse(value) == null) {
                  return 'Port harus berupa angka';
                }
                return null;
              },
            ),
            const SizedBox(height: 16),
            TextFormField(
              controller: topicController,
              decoration: InputDecoration(labelText: 'Topik'),
              validator: (value) {
                if (value == null || value.isEmpty) {
                  return 'Topik tidak boleh kosong';
                }
                return null;
              },
            ),
            const SizedBox(height: 32),
            ElevatedButton.icon(
              onPressed: _connectToBroker,
              icon: Icon(Icons.cloud_done),
              label: Text('Hubungkan'),
              style: ElevatedButton.styleFrom(
                backgroundColor: Colors.cyan,
                foregroundColor: Colors.white,
                padding: const EdgeInsets.symmetric(horizontal: 24, vertical: 12),
              ),
            ),
            const SizedBox(height: 16),
            Text(
              _statusMessage,
              style: TextStyle(color: Colors.white70),
            ),
          ],
        ),
      ),
    );
  }
}
