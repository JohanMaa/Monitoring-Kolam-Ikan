class SensorData {
  final double suhu;
  final double ph;
  final double kekeruhan;

  SensorData({required this.suhu, required this.ph, required this.kekeruhan});

  factory SensorData.fromJson(Map<String, dynamic> json) {
    return SensorData(
      suhu: (json['suhu'] ?? 0).toDouble(),
      ph: (json['ph'] ?? 0).toDouble(),
      kekeruhan: (json['kekeruhan'] ?? 0).toDouble(),
    );
  }
}
